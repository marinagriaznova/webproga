from django import forms

from .models import BookModel, AuthorModel, BookInstanceModel, GenreModel

class NewBookForm(forms.ModelForm):
	class Meta:
		model = BookModel
		fields = ('__all__')

class NewAuthorForm(forms.ModelForm):
	class Meta:
		model = AuthorModel
		fields = ('__all__')

class NewBookInstanceForm(forms.ModelForm):
	class Meta:
		model = BookInstanceModel
		fields = ('__all__')

class NewGenreForm(forms.ModelForm):
	class Meta:
		model = GenreModel
		fields = ('__all__')