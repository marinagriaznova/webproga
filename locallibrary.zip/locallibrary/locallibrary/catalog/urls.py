from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('add-author', views.new_author, name="add-author"),
    path('add-book', views.new_book, name="add-book"),
    path('add-bookinstance', views.new_bookinstance, name="add-bookinstance"),
    path('add-genre', views.new_genre, name="add-genre")
]