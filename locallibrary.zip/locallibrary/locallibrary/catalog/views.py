from django.shortcuts import render
from django.views.generic import CreateView
from .models import BookModel, BookInstanceModel, AuthorModel, GenreModel
from .forms import NewBookForm, NewGenreForm, NewAuthorForm, NewBookInstanceForm

def index(request):
	num_books = BookModel.objects.all().count()
	'''model = BookModel
	fields = ('__all__')'''

	num_instances = BookInstanceModel.objects.all().count()
	'''model = BookInstanceModel
	fields = ('__all__')'''

	num_instances_available = BookInstanceModel.objects.filter(status='a')

	num_authors = AuthorModel.objects.all().count()
	'''model = AuthorModel
	fields = ('__all__')'''

	'''return render(
		request,
		'index.html',
		context={
			'num_books': num_books,
			'num_instances': num_instances,
			'num_instances_available': num_instances_available,
			'num_authors': num_authors,
		})'''
	
'''class AuthorCreateView(CreateView):
	model = AuthorModel
	fields = ('__all__')'''

def new_author(request):
	form = NewAuthorForm()
	return render(request, 'catalog/authormodel_form.html', {'form': form})

'''class BookCreateView(CreateView):
	model = BookModel
	fields = ('__all__')'''

def new_book(request):
	form = NewBookForm()
	return render(request, 'catalog/bookmodel_form.html', {'form': form})
	
'''class BookInstanceCreateView(CreateView):
	model = BookInstanceModel
	fields = ('__all__')'''

def new_bookinstance(request):
	form = NewBookInstanceForm()
	return render(request, 'catalog/bookinstancemodel_form.html', {'form': form}) 

'''class GenreCreateView(CreateView):
	model = GenreModel
	fields = ('__all__')'''

def new_genre(request):
	form = NewGenreForm()
	return render(request, 'catalog/genremodel_form.html', {'form': form})